#! /bin/bash
echo 'Generated emailsSent';
