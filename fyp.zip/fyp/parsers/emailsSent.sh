#! /bin/bash
> /fyp/parsers/emailsSent
