<?php

$f = file_get_contents("/var/www/error.log");

if(empty($f)){
file_put_contents('/fyp/parsers/apacheAlerts',"");
die("No logs to alert\n");
}

$contents = explode("\n",$f);

$warnings = array();

foreach($contents as $line){
	if(!empty($line)){
	$warnings[] = $line;
	}
}

// Write each to alerts file
file_put_contents('/fyp/parsers/apacheAlerts','');
foreach($warnings as $warning){

file_put_contents('/fyp/parsers/apacheAlerts',$warning . "|\n", FILE_APPEND);
}
file_put_contents('/var/www/error.log','');

?>
