<?php

$f = file_get_contents("/var/www/snort.log");

if(empty($f)){
file_put_contents('/fyp/parsers/snortAlerts',"");
die("No logs to alert\n");
}

$contents = explode("\n",$f);

$warnings = array();

foreach($contents as $line){

	if(strpos($line, "[**]") !== false){
	$warnings[] = $line;
	}
}

// Write each to alerts file
file_put_contents('/fyp/parsers/snortAlerts',"");
foreach($warnings as $warning){

file_put_contents('/fyp/parsers/snortAlerts',"[" . date('Y-m-d H:i:s') . "] ". $warning . "|\n",FILE_APPEND);
}
file_put_contents('/var/www/snort.log','');
?>
