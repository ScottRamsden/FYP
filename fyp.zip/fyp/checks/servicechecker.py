#!/usr/bin/python
import commands
import subprocess
output = commands.getoutput('ps -A')

items = []

# Load enabled modules
enabled = open("/fyp/modules/enabled")
enabledLines = enabled.readlines()

for enabledLine in enabledLines:
	line = enabledLine.split("\n")[0]
	line = line.split("#")[0]
	line = line.split("/")[1:]
	items = items + line

# Loop and create fyp output

for item in items:
	if item not in output:
	    	print item + "#"

