#!/bin/bash
echo "[$(date +"%Y-%m-%d/%T")] System booted succesfully|"  >> /fyp/parsers/emailsSent
sh /fyp/alerts/emailSend.sh scott@scottramsden.co.uk "FYP System Booted" "System Online"
