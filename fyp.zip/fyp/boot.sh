#!/bin/bash
echo "[$(date +"%Y-%m-%d/%T")] System booted succesfully|"  >> /fyp/parsers/emailsSent
