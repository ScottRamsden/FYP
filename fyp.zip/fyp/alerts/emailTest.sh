recipients="scott@scottramsden.co.uk"

/usr/sbin/sendmail "$recipients" <<EOF
subject:$subject
from:$from
Example Message From FYP
EOF
