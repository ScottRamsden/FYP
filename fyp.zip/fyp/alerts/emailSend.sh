recipients="$1"
message="$2"
subject="$3"
from="info@foryourprotection.co.uk"

/usr/sbin/sendmail "$recipients" <<EOF
subject:$subject
from:$from
$message
EOF
