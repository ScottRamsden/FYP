
from RPi import GPIO
from time import sleep

GPIO.setwarnings(False)

#Use the physical pin numbers, not the logical names
GPIO.setmode(GPIO.BOARD)

#Set pin 7 as output
GPIO.setup(7, GPIO.OUT)

#Keep looping over and over

for x in range(0, 3):

        #Turn pin 7 on
        GPIO.output(7, True)

        #Wait for 1 second
        sleep(1)

        #Turn pin 7 off
        GPIO.output(7, False)

        #Wait for 1 second
        sleep(1)
