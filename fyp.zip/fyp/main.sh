# Check services if data is return issue shortAlert.py

PYTHON=`python /fyp/checks/servicechecker.py`

if [ -n "$PYTHON" ]
then
	python /fyp/alerts/shortAlert.py
fi
