#! /bin/bash

while read line
do
echo "0.48\n$line" > /fyp/power/yesterday
done </fyp/power/today

cpu=`top -bn1 | grep "Cpu(s)" | sed "s/.*, *\([0-9.]*\)%* id.*/\1/" | awk '{print $1}'`

joules=16416

joules2=$(($joules/100))

joulesFinal=`echo "$joules2 * $cpu" | bc`

echo "0.48\n$joulesFinal" > /fyp/power/today
