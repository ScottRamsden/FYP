<?php

$app->get('/checkkey', function () {
    echo "error:empty:name";
});

$app->get('/checkkey/:name', function ($name) {

    // Check if $name exists
    $con=mysqli_connect("localhost","root","mesaF4UC","fypapi");
    // Check connection
    if (mysqli_connect_errno())
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }

    $result = mysqli_query($con,"SELECT * FROM accounts WHERE username = \"" . $name . "\" LIMIT 1");
    mysqli_close($con);
    if($result->num_rows != 0){

        // Check current time against saved generation time

        $time = time() - 1800;

        while($row = mysqli_fetch_array($result)){
            if($time < $row['keytime']){
                echo 'key:valid';
            }
            else{
                echo 'error:key:outdated';
            }
        }

    }
    else{

        echo 'error:auth:failed';

    }

});