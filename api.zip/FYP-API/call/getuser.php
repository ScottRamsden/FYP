<?php

function keyvalid($name){

    $service_url = 'http://runforthe33.co.uk/checkkey/' . $name;
    $curl = curl_init($service_url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $curl_response = curl_exec($curl);
    if ($curl_response === false) {
        $info = curl_getinfo($curl);
        curl_close($curl);
        die('error:timeout');
    }
    curl_close($curl);

    return $curl_response;
}

$app->get('/getuser', function () {
    echo "error:empty:name";
});

$app->get('/getuser/:name/', function () {
    echo "error:empty:key";
});

$app->get('/getuser/:name/:key', function ($name,$key) {


        // Check key is valid
        if(keyvalid($name) != "key:valid"){
            echo "key:outdated";
		var_dump(keyvalid($name));
            exit;
        }

        //sql pass - Li2BBiV726d18IC

        // Get the user from the database
        $con=mysqli_connect("localhost","root","mesaF4UC","fypapi");
        // Check connection
        if (mysqli_connect_errno())
        {
            echo "Failed to connect to MySQL: " . mysqli_connect_error();
        }

        $result = mysqli_query($con,"SELECT * FROM accounts WHERE username = \"" . $name . "\" LIMIT 1");
        mysqli_close($con);
        if($result->num_rows != 0){

        while($row = mysqli_fetch_array($result)){
            if($key == $row['apikey']){
            echo "" . $row['id'] . "|";
            echo "" . $row['username'] . "|";
            echo "" . $row['email'] . "|";
            }
            else{
                echo 'error:invalid:key';
            }
        }

        }
        else{
            echo "error:user:noexist";
        }


});
