<?php

function generateKey($length = 15) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomString;
}

$app->get('/auth', function () {
    echo "error:empty:name";
});

$app->get('/auth/:name/', function () {
    echo "error:empty:password";
});

$app->get('/auth/:name/:password', function ($name,$password) {

    // Check if $name exists
    $con=mysqli_connect("localhost","root","mesaF4UC","fypapi");
    // Check connection
    if (mysqli_connect_errno())
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }

    $result = mysqli_query($con,"SELECT * FROM accounts WHERE username = \"" . $name . "\" LIMIT 1");
    mysqli_close($con);
    if($result->num_rows != 0){


        // User exists so check their password
        while($row = mysqli_fetch_array($result)){
            $userPassword = $row['password'];
        }

        if($password == $userPassword){
            // Valid authentication, update their current $key and return $key

            $key = generateKey();

            $con=mysqli_connect("localhost","root","mesaF4UC","fypapi");
            // Check connection
            if (mysqli_connect_errno())
            {
                echo "Failed to connect to MySQL: " . mysqli_connect_error();
            }

            mysqli_query($con,"UPDATE accounts SET apikey = \"" . $key . "\" WHERE username = \"" . $name . "\"");
            mysqli_query($con,"UPDATE accounts SET keytime = \"" . time() . "\" WHERE username = \"" . $name . "\"");

            mysqli_close($con);
            echo 'newkey:' . $key;
        }
        else{
            echo 'error:auth:invalidpassword';
        }





    }
    else{

        echo 'error:auth:failed';

    }

});